package example

object Main extends App {
  val a = " Scala! This is "
  val b = "Hello"
  val c = "Hola"
  val name = "Anzhelika Kotovich"
  println(b + a + name)
  println(c + a + name)
  println(c + a + name.reverse)
  println(b + a + name.reverse)
}
